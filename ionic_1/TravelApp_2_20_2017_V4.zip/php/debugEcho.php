<?php
function echoDebug($debugString)
{
    //echo $debugString;
}
?>
