<?php
//connect to mysql database
$con = mysqli_connect("testdb.chsdaxp5cy30.us-east-1.rds.amazonaws.com", "TestDBUser", "phillesh1", "mydb") or die("Error " . mysqli_error($con));
?>