angular-post-php
================

Send POST data from angular to PHP.

Many people face problem in sending POST data from Angular.js Script to PHP. I have figured out easy way to do it.

Tutorial link: http://codeforgeek.com/2014/07/angular-post-request-php/
